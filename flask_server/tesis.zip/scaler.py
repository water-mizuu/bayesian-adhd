class EEGScaler:
    """Standardize EEG data per electrode (channel)."""
    def __init__(self):
        self.mean_ = None
        self.scale_ = None

    def fit(self, X):
        # X: (samples, freq, electrodes, 1)
        self.mean_ = X.mean(axis=(0, 1), keepdims=True)
        self.scale_ = X.std(axis=(0, 1), keepdims=True) + 1e-8
        return self

    def transform(self, X):
        return (X - self.mean_) / self.scale_

    def fit_transform(self, X):
        return self.fit(X).transform(X)

    def inverse_transform(self, X_scaled):
        return X_scaled * self.scale_ + self.mean_