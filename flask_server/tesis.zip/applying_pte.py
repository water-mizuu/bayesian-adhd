import numpy as np
import pandas as pd

import pickle
import torch

from scaler import EEGScaler

SAMPLE_RATE = 128             # Hz
WINDOW_SECONDS = 4            # window duration
OVERLAP = 0.5                 # 50% overlap
SAMPLES_PER_WINDOW = int(SAMPLE_RATE * WINDOW_SECONDS)
WINDOW_STEP = int(SAMPLES_PER_WINDOW * (1 - OVERLAP))    # step size for sliding window
TARGET_FREQUENCY_BINS = np.arange(2.0, 40.5, 0.5)        # target frequency bins

def process_window(window, window_count):
    output = []
    electrode_columns = window.select_dtypes(include=[np.number]).columns

    n = len(window)
    original_freqs = np.fft.rfftfreq(n, d=1 / SAMPLE_RATE)

    # compute power spectra for all electrodes
    electrode_powers = {}
    for electrode in electrode_columns:
        signal = window[electrode].to_numpy()
        fft_vals = np.fft.rfft(signal)
        power = np.abs(fft_vals) ** 2

        # interpolate to common freq bins
        electrode_powers[electrode] = np.interp(TARGET_FREQUENCY_BINS, original_freqs, power)

    # build rows: one per frequency bin
    for i, f in enumerate(TARGET_FREQUENCY_BINS):
        row = {
            "Window": window_count,
            "Frequency": f
        }
        for electrode in electrode_columns:
            row[electrode] = electrode_powers[electrode][i]
        output.append(row)
    return output


# Load the saved scaler.

scaler: EEGScaler = None
with open('exports/saved_scaler.pkl', 'rb') as file:
    scaler = pickle.load(file)

# Load the saved model.
params = {'batch_size': 32, 'cnn_dense': 256, 'cnn_dropout': np.float64(0.35249225970234016), 'cnn_kernel_size_1': 3, 'cnn_kernel_size_2': np.int64(1), 'cnn_kernels_1': 48, 'cnn_kernels_2': 64, 'learning_rate': np.float64(0.0001117141453008524), 'lstm_dense': 256, 'lstm_hidden_size': 96, 'lstm_layers': 2, 'optimizer': 'adam'}

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class EEG_CNN_LSTM_HPO(nn.Module):
    def __init__(self,
                 cnn_kernels_1=32,
                 cnn_kernel_size_1=3,
                 cnn_kernels_2=64,
                 cnn_kernel_size_2=3,
                 cnn_dropout=0.3,
                 cnn_dense=64,
                 lstm_hidden_size=64,
                 lstm_layers=2,
                 lstm_dense=64,
                 dropout=0.3,
                 num_classes=2):
        super().__init__()

        # --- CNN feature extractor (configurable) ---
        pad1 = cnn_kernel_size_1 // 2
        self.conv1 = nn.Conv2d(1, int(cnn_kernels_1), kernel_size=cnn_kernel_size_1, padding=pad1)
        self.pool1 = nn.AvgPool2d(2)
        pad2 = cnn_kernel_size_2 // 2
        self.conv2 = nn.Conv2d(int(cnn_kernels_1), int(cnn_kernels_2), kernel_size=cnn_kernel_size_2, padding=pad2)
        self.pool2 = nn.AvgPool2d(2)
        self.cnn_dropout = nn.Dropout(cnn_dropout)

        # compute dims after CNN using X_train shape present in the session
        with torch.no_grad():
            dummy = torch.zeros(1, 1, 77, 19)
            out = self._forward_cnn(dummy)
            # We'll treat width (W) as seq_len and flatten channels*height as feature_dim
            self.seq_len = out.size(-1)           # W
            self.feature_dim = out.size(1) * out.size(2)  # C * H

        # projection per time-step from feature_dim -> cnn_dense
        self.cnn_dense = nn.Linear(self.feature_dim, int(cnn_dense))

        # --- LSTM (takes cnn_dense as input_size) ---
        self.lstm = nn.LSTM(
            input_size=int(cnn_dense),
            hidden_size=int(lstm_hidden_size),
            num_layers=int(lstm_layers),
            batch_first=True,
            dropout=dropout if lstm_layers > 1 else 0.0
        )

        # optional dense after LSTM
        self.lstm_dense = nn.Linear(int(lstm_hidden_size), int(lstm_dense))

        # final classifier (match your original final style: dropout + linear)
        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(int(lstm_dense), num_classes)
        )

    def _forward_cnn(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = self.pool2(x)
        x = self.cnn_dropout(x)
        return x  # (N, C, H, W)

    def forward(self, x):
        # CNN extraction
        x = self._forward_cnn(x)           # (N, C, H, W)

        # Prepare for LSTM: treat W as sequence length, flatten C*H to feature
        x = x.permute(0, 3, 1, 2)          # (N, W, C, H)
        x = x.reshape(x.size(0), x.size(1), -1)  # (N, seq_len=W, feature_dim=C*H)

        # project per time-step
        x = F.relu(self.cnn_dense(x))      # (N, seq_len, cnn_dense)

        # LSTM
        _, (h_n, _) = self.lstm(x)         # h_n: (num_layers, batch, hidden)
        out = h_n[-1]                      # last layer hidden state -> (batch, hidden)

        # post-LSTM dense + classifier
        out = F.relu(self.lstm_dense(out))
        return self.classifier(out)

loaded_model = EEG_CNN_LSTM_HPO(
    cnn_kernels_1=params['cnn_kernels_1'],
    cnn_kernel_size_1=params['cnn_kernel_size_1'],
    cnn_kernels_2=params['cnn_kernels_2'],
    cnn_dropout=float(params['cnn_dropout']),
    cnn_dense=params['cnn_dense'],
    lstm_hidden_size=params['lstm_hidden_size'],
    lstm_layers=params['lstm_layers'],
    lstm_dense=params['lstm_dense'],
    dropout=float(params['cnn_dropout']),  # use cnn_dropout as a simple shared dropout param
    num_classes=2
)

weights = torch.load("exports/eeg_cnn_lstm_hpo.pth",
                     weights_only=True,
                     map_location=torch.device("cpu"))
loaded_model.load_state_dict(weights)
loaded_model.eval()

# Load the "EEG File"

## First, we load the "recording"
df = pd.read_csv("./adhdata.csv")

for i in range(df['ID'].nunique()):
    first_id = df['ID'].unique()[i]
    target_recording = df[df['ID'] == first_id].drop(['ID', 'Class'], axis=1)

    ## Then, we run it through the same preprocessing pipeline.

    start_windows = 0
    window_count = 0
    n_samples = len(target_recording)
    output = []

    # Sliding window with overlap
    for start in range(0, n_samples - SAMPLES_PER_WINDOW + 1, WINDOW_STEP):
        window = target_recording.iloc[start:start + SAMPLES_PER_WINDOW]
        rows = process_window(window, window_count)

        for row in rows:
            output.append(row)

        window_count += 1
        start_windows += 1

    # Create the dataframe from the windows.
    windows_dataframe = pd.DataFrame(output)

    frequency_count = len(windows_dataframe['Frequency'].unique())
    window_count = len(windows_dataframe['Window'].unique())
    numeric_df = windows_dataframe.drop(['Window', 'Frequency'], axis=1)

    # shape: (windows, freqs, features)
    full_ndarray = numeric_df.values.reshape((window_count, frequency_count, numeric_df.shape[1]))
    full_ndarray = scaler.transform(full_ndarray)
    full_ndarray = full_ndarray[..., np.newaxis]

    with torch.no_grad():
        tensor = torch.tensor(full_ndarray, dtype=torch.float32).permute(0, 3, 1, 2)
        predictions = loaded_model(tensor).softmax(1).detach().numpy()
        adhd, control = np.sum(predictions, axis=0) / np.sum(predictions)

        if adhd > control:
            print(f"The subject {i} is indicative of ADHD with {adhd * 100:.2f}% confidence.")
        else:
            print(f"The subject {i} is not indicative of ADHD with {control * 100:.2f}% confidence.")